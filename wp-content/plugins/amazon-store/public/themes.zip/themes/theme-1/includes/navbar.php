<?php
$flagImageUrl = BBIL_PLUGIN_DIR .'images/usa.png';
$AMAZON_PRODUCT = new amazon_cats(AWS_ACCESS_KEY, AWS_SECRET_KEY, ASSOCIATIVE_ID);
?>
<nav class="navbar navbar-secondery no-margin">
  	<div class="container-fluid">
  		<div class="navbar-header">
		    <?php
		    // enable xs menu button
		    echo '<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#header_top_nav_bar" aria-expanded="false">';
		    echo '<span class="sr-only">Toggle navigation</span>';
		    echo '<span class="icon-bar"></span>';
		    echo '<span class="icon-bar"></span>';
		    echo '<span class="icon-bar"></span>';
		    echo '</button>';

		    // XS cart
		    echo '<div class="header_xs_cart hidden-md hidden-lg pull-right" data-toggle="modal" data-target="#cart_pop">';
		    echo '<div class="cart-item"> <span>2</span> </div>';
		    echo '<a href="javascript:;"> <i class="fa fa-shopping-bag" aria-hidden="true"></i> </a>';
		    echo '</div>';

		    // XS flag
		    echo '<div id="xs-flag" class="hidden-md hidden-lg">';
		    echo '<img src="'. $flagImageUrl .'">';
		    echo '</div>';

		    // XS logo
		    echo $headerLogoImageOrText;
		    ?>
	    </div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="header_top_nav_bar">

            <?php echo headerMenu($AMAZON_PRODUCT); ?>
			
			<div class="navbar no-margin pull-right header_form">
				<?php
				echo '<div id="flag" class="hidden-xs hidden-sm">';
				echo '<img src="'. $flagImageUrl .'">';
				echo '</div>';

				include 'header_search_form.php';
				include 'cart_modal_btn.php';
				?>
	      	</div>
	    </div>
  	</div><!-- /.container-fluid -->
</nav>