<section id="promoSliderWrapper">
	<!-- Slider section-->
	<div id="promoSlider" class="carousel slide" data-ride="carousel">
	    <!-- Indicators -->
	    <ol class="carousel-indicators">
	      <li data-target="#promoSlider" data-slide-to="0" class="active"></li>
	      <li data-target="#promoSlider" data-slide-to="1"></li>
	      <li data-target="#promoSlider" data-slide-to="2"></li>
	    </ol>

	    <!-- Wrapper for slides -->
	    <div class="carousel-inner">
	      	<div class="item active">
	        	<img src="https://i.pinimg.com/originals/11/7a/15/117a158f926790b3e21489ae15116bff.jpg" alt="Los Angeles" style="width:100%;">
	      	</div>

	      	<div class="item">
	        	<iframe id="youtube" style="width: 100%; height: 674px;" src="http://www.youtube.com/embed/-w-58hQ9dLk?controls=1" allowfullscreen></iframe>
	      	</div>

	      	<div class="item">
	        	<img src="http://elementsmassage.com/files/shared/shutterstock_333722087.jpg" alt="Chicago" style="width:100%;">
	      	</div>
	    
	      	<div class="item">
	        	<img src="https://www.allkpop.com/upload/2016/07/af_org/Seo-In-Guk-yoon-sang-hyun-nam-ji-hyun_1468506749_af_org.jpg" alt="New york" style="width:100%;">
	      	</div>

	      	<div class="item">
	        	<img src="https://bestwaytodoit.files.wordpress.com/2012/08/asdasdasd2222.jpg" alt="New york" style="width:100%;">
	      	</div>
	    </div>

	    <!-- Left and right controls -->
	    <a class="left carousel-control" href="#promoSlider" data-slide="prev">
	      	<span class="glyphicon glyphicon-chevron-left"></span>
	      	<span class="sr-only">Previous</span>
	    </a>
	    <a class="right carousel-control" href="#promoSlider" data-slide="next">
	      	<span class="glyphicon glyphicon-chevron-right"></span>
	      	<span class="sr-only">Next</span>
	    </a>
	</div>

	<?php if (get_option('bbil_enableOnePageLandingPage') || get_option('bbil_enableLandingPage')) {
	    echo '<div class="clearfix"></div>';
	    include 'landing_page.php';
	} ?>
</section>